// src/utils/fileParser.js
// Parses CSV and Excel files into flat arrays of objects

import Papa   from 'papaparse'
import * as XLSX from 'xlsx'

/**
 * Parse an uploaded File object.
 * Returns: { data: Array<Object>, columns: string[], rowCount: number }
 */
export function parseFile(file) {
  return new Promise((resolve, reject) => {
    const ext = file.name.split('.').pop().toLowerCase()

    if (ext === 'csv') {
      Papa.parse(file, {
        header:        true,
        skipEmptyLines: true,
        complete: (result) => {
          const data    = result.data
          const columns = result.meta.fields || []
          resolve({ data, columns, rowCount: data.length })
        },
        error: reject,
      })
    } else if (['xlsx', 'xls'].includes(ext)) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const workbook = XLSX.read(e.target.result, { type: 'binary' })
          const sheet    = workbook.Sheets[workbook.SheetNames[0]]
          const data     = XLSX.utils.sheet_to_json(sheet, { defval: '' })
          const columns  = data.length > 0 ? Object.keys(data[0]) : []
          resolve({ data, columns, rowCount: data.length })
        } catch (err) {
          reject(err)
        }
      }
      reader.onerror = reject
      reader.readAsBinaryString(file)
    } else {
      reject(new Error(`Unsupported file type: .${ext}`))
    }
  })
}

/**
 * Export data array to CSV and trigger browser download.
 */
export function exportToCSV(data, filename = 'export.csv') {
  const csv  = Papa.unparse(data)
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url  = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href     = url
  link.download = filename
  link.click()
  URL.revokeObjectURL(url)
}

/**
 * Export data array to Excel (.xlsx) and trigger browser download.
 */
export function exportToExcel(data, filename = 'export.xlsx') {
  const ws = XLSX.utils.json_to_sheet(data)
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Results')
  XLSX.writeFile(wb, filename)
}

/**
 * Format file size bytes to human-readable string.
 */
export function formatFileSize(bytes) {
  if (bytes < 1024)       return `${bytes} B`
  if (bytes < 1024 ** 2)  return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 ** 2).toFixed(2)} MB`
}
