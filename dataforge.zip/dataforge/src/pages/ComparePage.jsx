import { useState, useCallback } from 'react'
import { GitCompare, Play, Download, RotateCcw, CheckCircle, AlertTriangle, Minus } from 'lucide-react'
import FileDropZone  from '../components/ui/FileDropZone'
import ResultsTable  from '../components/ui/ResultsTable'
import { parseFile, exportToCSV, exportToExcel } from '../utils/fileParser'
import { compareDatasets, commonColumns }         from '../utils/compareEngine'
import { trackUpload, trackComparison }           from '../services/analyticsService'
import { useAuth } from '../hooks/useAuth'

const TABS = [
  { id: 'matched',  label: 'Matched',       icon: CheckCircle,   color: 'text-accent-green' },
  { id: 'diffs',    label: 'Differences',   icon: AlertTriangle, color: 'text-accent-amber' },
  { id: 'onlyIn1',  label: 'Only in File 1', icon: Minus,        color: 'text-brand-400' },
  { id: 'onlyIn2',  label: 'Only in File 2', icon: Minus,        color: 'text-accent-violet' },
]

export default function ComparePage() {
  const { user } = useAuth()

  // File state
  const [file1, setFile1] = useState(null)
  const [file2, setFile2] = useState(null)
  const [data1, setData1] = useState(null)
  const [data2, setData2] = useState(null)

  // Config
  const [keyCol,     setKeyCol]     = useState('')
  const [compareCols, setCompareCols] = useState([])

  // Results
  const [result,    setResult]    = useState(null)
  const [activeTab, setActiveTab] = useState('matched')
  const [loading,   setLoading]   = useState(false)
  const [error,     setError]     = useState('')

  const loadFile = async (file, setFile, setData, fileLabel) => {
    if (!file) { setFile(null); setData(null); return }
    setFile(file)
    setError('')
    try {
      const parsed = await parseFile(file)
      setData(parsed)
      await trackUpload({
        fileName: file.name,
        fileSize: file.size,
        rowCount: parsed.rowCount,
        userId:   user?.uid,
      })
    } catch (e) {
      setError(`Could not parse ${fileLabel}: ${e.message}`)
      setFile(null); setData(null)
    }
  }

  const handleRun = async () => {
    if (!data1 || !data2 || !keyCol) return
    setLoading(true)
    setError('')
    try {
      // Small delay so UI can render spinner
      await new Promise(r => setTimeout(r, 50))
      const res = compareDatasets(data1.data, data2.data, keyCol, compareCols)
      setResult(res)
      setActiveTab('matched')
      await trackComparison({
        file1Name:    file1.name,
        file2Name:    file2.name,
        matchedCount: res.summary.matched,
        missingCount: res.summary.onlyIn1 + res.summary.onlyIn2,
        userId:       user?.uid,
      })
    } catch (e) {
      setError(`Comparison error: ${e.message}`)
    }
    setLoading(false)
  }

  const reset = () => {
    setFile1(null); setFile2(null); setData1(null); setData2(null)
    setKeyCol(''); setCompareCols([]); setResult(null); setError('')
  }

  const sharedCols   = data1 && data2 ? commonColumns(data1.columns, data2.columns) : []
  const canRun       = data1 && data2 && keyCol && !loading
  const comparableExtras = sharedCols.filter(c => c !== keyCol)

  const getTableData = () => {
    if (!result) return { rows: [], columns: [] }
    switch (activeTab) {
      case 'matched':  return { rows: result.matched,     columns: [...(data1?.columns ?? []).map(c => `f1_${c}`), ...(data2?.columns ?? []).map(c => `f2_${c}`)], highlightDiffs: false }
      case 'diffs':    return { rows: result.matched.filter(r => r._hasDiff), columns: [...(data1?.columns ?? []).map(c => `f1_${c}`), ...(data2?.columns ?? []).map(c => `f2_${c}`)], highlightDiffs: true }
      case 'onlyIn1':  return { rows: result.onlyInFile1, columns: data1?.columns ?? [] }
      case 'onlyIn2':  return { rows: result.onlyInFile2, columns: data2?.columns ?? [] }
      default:         return { rows: [], columns: [] }
    }
  }

  const handleExport = (format) => {
    const { rows, columns } = getTableData()
    const exportData = rows.map(r => {
      const obj = {}
      columns.filter(c => !c.startsWith('_')).forEach(c => {
        obj[c.replace(/^f[12]_/, '')] = r[c] ?? ''
      })
      return obj
    })
    const name = `dataforge_${activeTab}_${Date.now()}`
    if (format === 'csv')   exportToCSV(exportData,   `${name}.csv`)
    if (format === 'excel') exportToExcel(exportData, `${name}.xlsx`)
  }

  const { rows, columns, highlightDiffs } = getTableData()

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-white flex items-center gap-3">
            <GitCompare size={28} className="text-brand-500" />
            File Comparison
          </h1>
          <p className="text-slate-400 mt-1">Upload two files, choose a key column, and run the comparison.</p>
        </div>
        {(data1 || data2 || result) && (
          <button onClick={reset} className="btn-ghost">
            <RotateCcw size={14} /> Reset
          </button>
        )}
      </div>

      {error && (
        <div className="glass border-rose-500/30 bg-rose-500/10 p-4 text-rose-400 text-sm rounded-xl flex items-center gap-2">
          <AlertTriangle size={16} /> {error}
        </div>
      )}

      {/* File uploads */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-2">
          <p className="text-sm font-semibold text-slate-300">File 1 (primary)</p>
          <FileDropZone
            label="Upload File 1"
            file={file1}
            onFile={(f) => loadFile(f, setFile1, setData1, 'File 1')}
          />
          {data1 && (
            <p className="text-xs text-slate-500 pl-1">
              {data1.rowCount.toLocaleString()} rows · {data1.columns.length} columns
            </p>
          )}
        </div>
        <div className="space-y-2">
          <p className="text-sm font-semibold text-slate-300">File 2 (compare against)</p>
          <FileDropZone
            label="Upload File 2"
            file={file2}
            onFile={(f) => loadFile(f, setFile2, setData2, 'File 2')}
          />
          {data2 && (
            <p className="text-xs text-slate-500 pl-1">
              {data2.rowCount.toLocaleString()} rows · {data2.columns.length} columns
            </p>
          )}
        </div>
      </div>

      {/* Config panel */}
      {sharedCols.length > 0 && (
        <div className="glass p-6 space-y-5 animate-fade-up">
          <h2 className="font-semibold text-white">Comparison Settings</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Key column */}
            <div className="space-y-2">
              <label className="text-sm text-slate-400 font-medium">
                Key column <span className="text-rose-400">*</span>
              </label>
              <select
                value={keyCol}
                onChange={(e) => setKeyCol(e.target.value)}
                className="input"
              >
                <option value="">Select key column…</option>
                {sharedCols.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <p className="text-xs text-slate-500">The column used to match rows between files.</p>
            </div>

            {/* Compare columns */}
            <div className="space-y-2">
              <label className="text-sm text-slate-400 font-medium">
                Columns to diff <span className="text-slate-500">(optional)</span>
              </label>
              <div className="glass-darker rounded-xl p-3 max-h-40 overflow-y-auto space-y-1.5">
                {comparableExtras.length === 0 ? (
                  <p className="text-xs text-slate-600">No additional shared columns.</p>
                ) : comparableExtras.map(col => (
                  <label key={col} className="flex items-center gap-2.5 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={compareCols.includes(col)}
                      onChange={(e) => {
                        setCompareCols(prev =>
                          e.target.checked ? [...prev, col] : prev.filter(c => c !== col)
                        )
                      }}
                      className="w-4 h-4 rounded accent-brand-500"
                    />
                    <span className="text-sm text-slate-300 group-hover:text-white transition-colors">{col}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={handleRun}
            disabled={!canRun}
            className="btn-primary w-full justify-center py-3 text-base disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                </svg>
                Running comparison…
              </span>
            ) : (
              <><Play size={16} /> Run Comparison</>
            )}
          </button>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-6 animate-fade-up">
          {/* Summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { label: 'File 1 rows',   value: result.summary.total1,    color: 'border-t-brand-500' },
              { label: 'File 2 rows',   value: result.summary.total2,    color: 'border-t-brand-500' },
              { label: 'Matched',       value: result.summary.matched,   color: 'border-t-accent-green' },
              { label: 'Only in File 1', value: result.summary.onlyIn1,  color: 'border-t-accent-amber' },
              { label: 'Only in File 2', value: result.summary.onlyIn2,  color: 'border-t-accent-violet' },
            ].map(({ label, value, color }) => (
              <div key={label} className={`stat-card border-t-2 ${color}`}>
                <p className="text-2xl font-bold font-mono text-white">{value.toLocaleString()}</p>
                <p className="text-xs text-slate-400">{label}</p>
              </div>
            ))}
          </div>

          {/* Tabs + export */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              {TABS.map(({ id, label, icon: Icon, color }) => {
                const count = id === 'matched'
                  ? result.summary.matched
                  : id === 'diffs'
                  ? result.matched.filter(r => r._hasDiff).length
                  : id === 'onlyIn1'
                  ? result.summary.onlyIn1
                  : result.summary.onlyIn2

                return (
                  <button
                    key={id}
                    onClick={() => setActiveTab(id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-150
                      ${activeTab === id
                        ? 'bg-white/10 text-white border border-white/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'}`}
                  >
                    <Icon size={14} className={activeTab === id ? color : ''} />
                    {label}
                    <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${activeTab === id ? 'bg-white/10' : 'bg-white/5'}`}>
                      {count}
                    </span>
                  </button>
                )
              })}
            </div>

            <div className="flex gap-2">
              <button onClick={() => handleExport('csv')}   className="btn-ghost text-sm py-2 px-3">
                <Download size={13} /> CSV
              </button>
              <button onClick={() => handleExport('excel')} className="btn-ghost text-sm py-2 px-3">
                <Download size={13} /> Excel
              </button>
            </div>
          </div>

          <ResultsTable columns={columns} rows={rows} highlightDiffs={highlightDiffs} />
        </div>
      )}
    </div>
  )
}
