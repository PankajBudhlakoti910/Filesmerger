import { Link } from 'react-router-dom'
import { GitCompare, Zap, Shield, Download, ChevronRight, BarChart3, FileSpreadsheet, AlertTriangle } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'

const features = [
  {
    icon: FileSpreadsheet,
    color: 'text-brand-500',
    bg:    'bg-brand-500/10',
    title: 'CSV & Excel Support',
    desc:  'Upload any CSV or Excel file. Auto-detects columns and parses data instantly — no configuration needed.',
  },
  {
    icon: GitCompare,
    color: 'text-accent-violet',
    bg:    'bg-accent-violet/10',
    title: 'Smart Comparison',
    desc:  'Match rows by any key column. See matched records, missing entries, and cell-level differences side by side.',
  },
  {
    icon: AlertTriangle,
    color: 'text-accent-amber',
    bg:    'bg-accent-amber/10',
    title: 'Missing Record Detection',
    desc:  'Instantly identify records present in one file but absent in the other — with a one-click export.',
  },
  {
    icon: Download,
    color: 'text-accent-green',
    bg:    'bg-accent-green/10',
    title: 'Export Results',
    desc:  'Download matched, missing, and diff results as CSV or Excel files for reporting or further analysis.',
  },
  {
    icon: Zap,
    color: 'text-yellow-400',
    bg:    'bg-yellow-400/10',
    title: 'Fast & Private',
    desc:  'All processing runs in your browser. Your file data never leaves your device — only metadata is tracked.',
  },
  {
    icon: Shield,
    color: 'text-rose-400',
    bg:    'bg-rose-400/10',
    title: 'Secure Auth',
    desc:  'Google and email login via Firebase Authentication. Role-based admin access for analytics.',
  },
]

const steps = [
  { n: '01', label: 'Upload two files', desc: 'CSV or Excel (.xlsx / .xls)' },
  { n: '02', label: 'Choose key column', desc: 'The field to match rows on' },
  { n: '03', label: 'Run comparison',   desc: 'Instant analysis in your browser' },
  { n: '04', label: 'Download results', desc: 'CSV or Excel export' },
]

export default function HomePage() {
  const { user } = useAuth()

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 space-y-28">
      {/* ── Hero ── */}
      <section className="text-center space-y-8 animate-fade-up">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-brand-500/30 bg-brand-500/10 text-brand-400 text-xs font-semibold mb-2">
          <BarChart3 size={12} />
          Professional Data Comparison
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-extrabold tracking-tight leading-none">
          <span className="text-white">Compare files.</span>
          <br />
          <span className="bg-gradient-to-r from-brand-500 via-blue-400 to-accent-violet bg-clip-text text-transparent">
            Find differences.
          </span>
        </h1>

        <p className="max-w-2xl mx-auto text-lg text-slate-400 leading-relaxed">
          Upload two CSV or Excel datasets, pick a key column, and instantly see matched records,
          missing entries, and cell-level differences. Export everything with one click.
        </p>

        <div className="flex flex-wrap gap-4 justify-center">
          <Link to={user ? '/compare' : '/login'} className="btn-primary text-base px-7 py-3">
            <GitCompare size={18} />
            Start Comparing
            <ChevronRight size={16} />
          </Link>
          {!user && (
            <Link to="/login" className="btn-ghost text-base px-7 py-3">
              Sign in free
            </Link>
          )}
        </div>
      </section>

      {/* ── How it works ── */}
      <section className="space-y-10 animate-fade-up anim-delay-200">
        <div className="text-center">
          <h2 className="text-3xl font-display font-bold text-white">How it works</h2>
          <p className="mt-2 text-slate-400">Four simple steps</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map(({ n, label, desc }, i) => (
            <div key={n} className="glass p-6 relative overflow-hidden group">
              <div className="absolute top-4 right-4 font-mono text-4xl font-bold text-white/5 group-hover:text-white/10 transition-colors">
                {n}
              </div>
              <div className="text-brand-500 font-mono text-sm font-bold mb-3">{n}</div>
              <p className="font-semibold text-white">{label}</p>
              <p className="text-sm text-slate-400 mt-1">{desc}</p>
              {i < steps.length - 1 && (
                <ChevronRight size={16} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 text-brand-500/40 hidden lg:block" />
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ── */}
      <section className="space-y-10 animate-fade-up anim-delay-300">
        <div className="text-center">
          <h2 className="text-3xl font-display font-bold text-white">Everything you need</h2>
          <p className="mt-2 text-slate-400">Powerful features in a simple interface</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map(({ icon: Icon, color, bg, title, desc }) => (
            <div key={title} className="glass p-6 space-y-3 group hover:border-white/20 transition-all duration-200">
              <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center`}>
                <Icon size={20} className={color} />
              </div>
              <h3 className="font-semibold text-white">{title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="relative text-center glass p-12 overflow-hidden animate-fade-up anim-delay-400">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-500/10 via-transparent to-accent-violet/10 pointer-events-none" />
        <h2 className="text-3xl font-display font-bold text-white relative">Ready to compare?</h2>
        <p className="mt-3 text-slate-400 relative">Sign in free and run your first comparison in seconds.</p>
        <div className="mt-8 flex justify-center gap-4 relative">
          <Link to={user ? '/compare' : '/login'} className="btn-primary text-base px-8 py-3">
            <GitCompare size={18} />
            {user ? 'Open Comparison Tool' : 'Get Started Free'}
          </Link>
        </div>
      </section>
    </div>
  )
}
