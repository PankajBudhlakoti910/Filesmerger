import { Routes, Route, Navigate } from 'react-router-dom'
import { useEffect } from 'react'
import Layout        from './components/layout/Layout'
import HomePage      from './pages/HomePage'
import ComparePage   from './pages/ComparePage'
import LoginPage     from './pages/LoginPage'
import AdminPage     from './pages/AdminPage'
import { useAuth }   from './hooks/useAuth'
import { trackVisit } from './services/analyticsService'

function RequireAuth({ children }) {
  const { user, loading } = useAuth()
  if (loading) return null
  return user ? children : <Navigate to="/login" replace />
}

function RequireAdmin({ children }) {
  const { admin, loading } = useAuth()
  if (loading) return null
  return admin ? children : <Navigate to="/" replace />
}

export default function App() {
  const { user } = useAuth()

  // Track page visit once on load
  useEffect(() => {
    trackVisit(user?.uid)
  }, []) // eslint-disable-line

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/"        element={<HomePage />} />
        <Route path="/compare" element={<RequireAuth><ComparePage /></RequireAuth>} />
        <Route path="/login"   element={<LoginPage />} />
        <Route path="/admin"   element={<RequireAdmin><AdminPage /></RequireAdmin>} />
      </Route>
    </Routes>
  )
}
